<?php
include "header.php";

echo "<h2>About this Site</h2>";

include "footer.php";

?>