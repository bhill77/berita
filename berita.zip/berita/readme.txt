this is just an example of my work while studying about 1 year ago

import berita.sql to your database and edit config.php


login
-------
user : admin
pass : 123