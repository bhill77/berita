	</div><!--end content-->

	<div id="footer">

		<p>&copy; 2012 situs berita</p>
	</div>
</div>
</body>
</html>